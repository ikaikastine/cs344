I've included a makefile to make the compiling process easier. 
To compile just run the command:

make

It does create the various object files, so if you'd like to 
clean up the files run:

make clean
